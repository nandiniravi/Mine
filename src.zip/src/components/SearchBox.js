import React from 'react';
import './SearchBox.css';

const SearchBox = () => {
    return(
        <div className='SearchBox'>
        <ul>
            <li><i className="fa fa-clock-o" style={{color:'#dfe1e5', fontSize: '20px', marginRight: '10px'}}></i>Search Result 1</li><span className='Remove'>Remove</span>
            <li><i className="fa fa-clock-o" style={{color:'#dfe1e5', fontSize: '20px', marginRight: '10px'}}></i>Search Result 2</li><span className='Remove'>Remove</span>
            <li><i className="fa fa-clock-o" style={{color:'#dfe1e5', fontSize: '20px', marginRight: '10px'}}></i>Search Result 3</li><span className='Remove'>Remove</span>
            <li><i className="fa fa-clock-o" style={{color:'#dfe1e5', fontSize: '20px', marginRight: '10px'}}></i>Search Result 4</li><span className='Remove'>Remove</span>
        </ul>
        <div className='ButtonContainer2'>
            <button>Google Search</button>
            <button>I'm Feeling Lucky</button>
        </div>
        <div className='last'><em><a href='/'>Report Inappropriate Predictions</a></em></div>
        </div>
    );
}

export default SearchBox;