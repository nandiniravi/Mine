import React, {useState} from 'react';
import logo from './logo.svg';
import './App.css';
import google from './assets/google.jpg';
import SearchBox from './components/SearchBox';

function App() {
  const [searchText, setSearchText] = useState();
  const [showBox, setShowBox] = useState(false);

  const contentLang = 
    <React.Fragment>
      <div className='ButtonContainer'>
        <button>Google Search</button>
        <button>I'm Feeling Lucky</button>
      </div>
      <div className="Lang">
        <span>Google offered in:</span>&nbsp;&nbsp;
        <a href='/'>हिन्दी</a>
        <a href='/'>বাংলা</a>
        <a href='/'>తెలుగు</a>
        <a href='/'>मराठी</a>
        <a href='/'>தமிழ்</a>
        <a href='/'>ગુજરાતી</a>
        <a href='/'>ಕನ್ನಡ</a>
        <a href='/'>മലയാളം</a>
        <a href='/'>ਪੰਜਾਬੀ</a>
      </div>
    </React.Fragment>;

    
  return (
    <div className="App">
      <img src={google} alt='Google Logo' className='GoogleImg'/>
      <div className='InputBoxContainer'>
        <span><i className="fa fa-search" style={{color: '#9aa0a6'}}></i></span>
        <input type='text' className='InputBox'
          value={searchText}
          onChange={(event) => setShowBox(true)}
        />
        <span><i className='fas fa-microphone' style={{color: '#4285F4'}}></i></span>
      </div>
      {showBox ? <SearchBox/> : contentLang}
      </div>
  );
}

export default App;
