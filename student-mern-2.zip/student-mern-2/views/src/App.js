import React from 'react';
import './App.css';
import Students from './components/Students/Students';

function App() {
  return (
    <div className="App">
      <h1>Students Records</h1>
      <Students/>
    </div>
  );
}

export default App;
