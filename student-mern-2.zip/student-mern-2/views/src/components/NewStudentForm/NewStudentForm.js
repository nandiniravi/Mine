import React, {useState} from 'react';
import './NewStudentForm.css';
import Popup from '../Popup/Popup';

const NewStudentForm = (props) => {
    const [newStudent, setNewStudent] = useState({
        rollNo: '',
        fullName: '',
        grade: '',
        maths: '',
        science: '',
        english:''
    });
    // const [resData, setresData] = useState(false);
    
    const submitForm = (event) => {
        event.preventDefault();
        console.log(newStudent);
        fetch('/api/students/post',
            {   method: 'POST',
                headers: {
                'Content-Type': 'application/json'
                },
                body: JSON.stringify(newStudent)
            }
        )
        .then(response => response.json())
        .then(data => console.log(data.msg));

        props.show();
    }

    const close = (event) => {
        props.show();
    }

    return(
        <div className="NewForm">
            <h3>Student Form</h3>
            <form>
                <label>Roll No</label>
                <input type="Number"
                    min="1"
                    max="100"
                    value={newStudent.rollNo}
                    onChange={(event) => setNewStudent({...newStudent, rollNo: event.target.value})}/>

                <label>Full Name</label>
                <input type="text"
                    value={newStudent.fullName}
                    onChange={(event) => setNewStudent({...newStudent, fullName: event.target.value})}/>

                <label>Grade</label>
                <input type="Number"
                    min="1"
                    max="10"
                    value={newStudent.grade}
                    onChange={(event) => setNewStudent({...newStudent, grade: event.target.value})}/>

                <label>Maths Score</label>
                <input type="Number"
                    min="1"
                    max="100"
                    value={newStudent.maths}
                    onChange={(event) => setNewStudent({...newStudent, maths: event.target.value})}/>

                <label>Science Score</label>
                <input type="Number"
                    min="1"
                    max="100"
                    value={newStudent.science}
                    onChange={(event) => setNewStudent({...newStudent, science: event.target.value})}/>

                <label>English Score</label>
                <input type="Number"
                    min="1"
                    max="100"
                    value={newStudent.english}
                    onChange={(event) => setNewStudent({...newStudent, english: event.target.value})}/>

                <button className="Submit" onClick={(event) => submitForm(event)}>Submit</button>
                <button className="Submit" onClick={(event) => close(event)}>Cancel</button>
            </form>
        </div>
    );
}

export default NewStudentForm;