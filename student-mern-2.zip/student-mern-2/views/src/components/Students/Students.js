import React, {useState, useEffect} from 'react';
import './Students.css';
import NewStudentForm from '../NewStudentForm/NewStudentForm';
import EditForm from '../EditForm/EditForm';

const Students = () => {
    const [studentsData, setstudentsData] = useState([]);
    const [showNewForm, setShowNewForm] = useState(false);
    const [showEditForm, setShowEditForm] = useState(false);
    const [chosenStudent, setChosenStudent] = useState();

    useEffect(() => {
        fetch('/api/students/')
        .then(response => response.json())
        .then(data => {
            console.log(data);
            setstudentsData(data.students);
            console.log('hi');
        });
    }, []);

    const showForm = () => {
        if (showNewForm === false)
            setShowNewForm(true);
        else
            setShowNewForm(false);
    }

    const showEdit = (id) => {
        if (showEditForm)
            setShowEditForm(false);
        else{
            console.log(id);
            const editStudent = studentsData.filter(each => (each._id === id));
            console.log(editStudent[0]);
            setChosenStudent(editStudent[0]);
            setShowEditForm(true);
        }
    }

    const deleteRecord = (id) => {
        fetch(`/api/students/delete/${id}`,{
            method: 'DELETE'
        });
    }

    return(
        <div>
            {showNewForm ? <NewStudentForm show={showForm}/> : null}
            {showEditForm ? <EditForm student={chosenStudent} show={showEdit}/> : null}
           <table style={{margin:"auto"}}>
                <tbody>
                <tr>
                    <th>Roll No</th>
                    <th>Full Name</th>
                    <th>Grade</th>
                    <th>Maths Score</th>
                    <th>Science Score</th>
                    <th>English Score</th>
                    <th colSpan="2"><button onClick={() => showForm()}>Add New</button></th>
                </tr>
                {studentsData.map(each => {
                    return( 
                        <tr key={each._id}>
                            <td>{each.rollNo}</td>
                            <td>{each.fullName}</td>
                            <td>{each.grade}</td>
                            <td>{each.maths}</td>
                            <td>{each.science}</td>
                            <td>{each.english}</td>
                            <td><button onClick={() => showEdit(each._id)}>Edit</button></td>
                            <td><button onClick={() => deleteRecord(each._id)}>Delete</button></td>
                        </tr>
                    );
                })}
                </tbody>
            </table>
        </div>
    );
}

export default Students;