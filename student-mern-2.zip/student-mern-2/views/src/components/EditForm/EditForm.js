import React, {useState} from 'react';
import '../NewStudentForm/NewStudentForm.css';

const EditForm = (props) => {
    const [chosenStudent, setChosenStudent] = useState({
        // id: props.student._id,
        rollNo: props.student.rollNo,
        fullName: props.student.fullName,
        grade: props.student.grade,
        maths: props.student.maths,
        science: props.student.science,
        english:props.student.english
    });

    const submitEditForm = (event) => {
        event.preventDefault();
        console.log(chosenStudent);
        fetch(`/api/students/update/${props.student._id}`,{
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
                body: JSON.stringify(chosenStudent)
        });
        props.show();
    }

    const close = (event) => {
        props.show();
    }

    return(
        <div className="NewForm">
            <h3>Edit Student Record</h3>
            <form>
                <label>Roll No</label>
                <input type="Number"
                    min="1"
                    max="100"
                    value={chosenStudent.rollNo}
                    onChange={(event) => setChosenStudent({...chosenStudent, rollNo: event.target.value})}/>

                <label>Full Name</label>
                <input type="text"
                    value={chosenStudent.fullName}
                    onChange={(event) => setChosenStudent({...chosenStudent, fullName: event.target.value})}/>

                <label>Grade</label>
                <input type="Number"
                    min="1"
                    max="10"
                    value={chosenStudent.grade}
                    onChange={(event) => setChosenStudent({...chosenStudent, grade: event.target.value})}/>

                <label>Maths Score</label>
                <input type="Number"
                    min="1"
                    max="100"
                    value={chosenStudent.maths}
                    onChange={(event) => setChosenStudent({...chosenStudent, maths: event.target.value})}/>

                <label>Science Score</label>
                <input type="Number"
                    min="1"
                    max="100"
                    value={chosenStudent.science}
                    onChange={(event) => setChosenStudent({...chosenStudent, science: event.target.value})}/>

                <label>English Score</label>
                <input type="Number"
                    min="1"
                    max="100"
                    value={chosenStudent.english}
                    onChange={(event) => setChosenStudent({...chosenStudent, english: event.target.value})}/>

                <button className="Submit" onClick={(event) => submitEditForm(event)}>Submit</button>
                <button className="Submit" onClick={(event) => close(event)}>Cancel</button>
            </form>
        </div>
    );
}

export default EditForm;