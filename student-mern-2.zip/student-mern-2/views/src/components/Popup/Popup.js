import React from 'react';
import './Popup.css';

const Popup = (props) => {
    return (
    <div className="Popup">
        <h1>{props.msg}</h1>
    </div>);
}

export default Popup;