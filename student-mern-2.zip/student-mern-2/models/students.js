const mongoose = require('mongoose');

const studentSchema = mongoose.Schema({
    rollNo : {
        type: Number,
        required: true
    },
    fullName: {
        type: String,
        required: true
    },
    grade: {
        type: Number,
        required: true
    },
    maths: {
        type: Number,
        required: true
    },
    science: {
        type: Number,
        required: true
    },
    english:{
        type: Number,
        required: true
    }
});

module.exports = new mongoose.model('Student', studentSchema);