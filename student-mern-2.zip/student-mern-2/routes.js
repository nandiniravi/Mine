const express = require('express');
const router = express.Router();
const Student = require('./models/students');


/*GET - get student details*/
router.get('/', async(req,res,next) => {
    try{    
        const students = await Student.find().sort({rollNo: 1});
        // console.log(students);
        res.json({students : students});
    }
    catch(err){
        res.status(400).json({msg : err});
    }
});

/*POST - add new student to record*/
router.post('/post', async(req,res,next) => {
    const newStudent = await new Student({
        rollNo: req.body.rollNo,
        fullName: req.body.fullName,
        grade: req.body.grade,
        maths: req.body.maths,
        science: req.body.science,
        english: req.body.english
    });
    try{
        await newStudent.save();
        res.json({msg: 'Record added!'});
    }
    catch(err){
        res.status(400).json({msg : err});
    }
});

/*PUT - updated student details*/
router.put('/update/:id', async(req,res,next) => {
    const studentId = req.params.id;
    let editStudent = await Student.findById(studentId);
            editStudent.rollNo= req.body.rollNo,
            editStudent.fullName= req.body.fullName,
            editStudent.grade= req.body.grade,
            editStudent.maths= req.body.maths,
            editStudent.science= req.body.science,
            editStudent.english= req.body.english
    try{
        // console.log(editStudent);
        await editStudent.save();
        res.json({msg: 'Record updated!'});
    }
    catch(err){
        res.status(400).json({msg : err});
    }

});

/*DELETE - delete student record*/
router.delete('/delete/:id', async(req,res,next) => {
    const studentId = req.params.id;
    try{
        let deleteStudent = Student.findById(studentId);
        await deleteStudent.remove();
        res.json({msg: 'Record deleted!'});
    }
    catch(err){
        res.status(400).json({msg : err});
    }
});

module.exports = router;