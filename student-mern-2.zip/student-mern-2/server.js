const express = require('express');
const app = express();
const mongoose = require('mongoose');
const routes = require('./routes');
const bodyParser = require('body-parser');


app.use(bodyParser.json());
app.use('/api/students', routes);

mongoose.connect('mongodb+srv://nravi:jD7NxjFgzG2o7UEx@cluster0.nrpwm.mongodb.net/test?retryWrites=true&w=majority',
    {   useNewUrlParser: true,
        useUnifiedTopology: true
    })
    .then(() => {
        console.log('Mongo DB connected');
        app.listen(5000, console.log('Server listening at port 5000...'));
    })
    .catch((err) => console.log(err));

